bin/solr stop -all
