bin/solr start -s ~/solr/solr-5.3.0/projectB/solr
